import React, { memo } from 'react';

interface FloatingStickerProps {
  src: string;
  fallbackSrc: string;
  alt: string;
  className?: string;
  style?: React.CSSProperties;
  variant?: 'normal' | 'alt';
  width?: number;
  height?: number;
  loading?: 'lazy' | 'eager';
}

export const FloatingSticker: React.FC<FloatingStickerProps> = memo(({
  src,
  fallbackSrc,
  alt,
  className = '',
  style = {},
  variant = 'normal',
  width = 240,
  height = 240,
  loading = 'lazy',
}) => {
  const animClass = variant === 'alt' ? 'animate-sticker-float-alt' : 'animate-sticker-float';

  return (
    <div
      className={`pointer-events-none md:pointer-events-auto select-none transition-transform duration-300 hover:scale-110 z-20 ${className}`}
      style={{
        filter: 'drop-shadow(0 14px 28px rgba(0,0,0,0.9)) drop-shadow(0 0 25px rgba(0,136,255,0.35))',
        ...style,
      }}
    >
      <img
        src={src}
        alt={alt}
        width={width}
        height={height}
        loading={loading}
        decoding="async"
        fetchPriority={loading === 'eager' ? 'high' : 'low'}
        referrerPolicy="no-referrer"
        onError={(e) => {
          if (fallbackSrc && e.currentTarget.src !== fallbackSrc) {
            e.currentTarget.src = fallbackSrc;
          }
        }}
        className={`w-full h-auto object-contain block ${animClass}`}
      />
    </div>
  );
});

FloatingSticker.displayName = 'FloatingSticker';
